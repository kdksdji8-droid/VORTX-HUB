VORTX HUB — PUBLIC DEPLOYMENT STARTER
=====================================

WHAT IS INCLUDED
- index.html: responsive public site + procedural Three.js hologram + Supabase email/password auth + cloud project CRUD + code editor/download + AI chat UI.
- schema.sql: projects table and row-level security policies (users can only access their own projects).
- functions/api/chat.js: Cloudflare Pages Function configured for Groq API; API key stays in Cloudflare Secrets.
- _headers: basic security headers.
- This is a deployment starter, not a live website yet. It becomes usable only after you create/configure the external services below.

A) SUPABASE DATABASE + LOGIN
1. Create a project at https://supabase.com/
2. In its SQL Editor, paste and run the full contents of schema.sql.
3. Open Project Settings > API (or Connect) and copy the Project URL and anon/public key.
4. In index.html, replace:
   PASTE_YOUR_SUPABASE_PROJECT_URL_HERE
   PASTE_YOUR_SUPABASE_ANON_KEY_HERE
   with those values. The anon/public key is meant for browser clients; never use a service_role key in index.html.
5. In Supabase Authentication settings, configure the Site URL and allowed redirect URLs to your eventual Cloudflare Pages domain. For a public site, choose email confirmation settings deliberately.

B) DEPLOY TO CLOUDFLARE PAGES
1. Extract the ZIP on a computer or phone.
2. Create a GitHub repository and upload the extracted files/folders preserving structure:
   index.html
   schema.sql
   _headers
   functions/api/chat.js
3. In Cloudflare Dashboard > Workers & Pages, create a Pages project and connect the repository.
4. Framework preset: None. Build command: leave empty. Build output directory: / (root).
5. Deploy. Pages Functions under functions/ are deployed with the site.
6. Add your deployed domain to Supabase Authentication URL configuration, then redeploy if you changed code.

C) ENABLE REAL AI CHAT WITH YOUR GROQ KEY (OPTIONAL)
1. Your key starts with gsk_, which is the Groq API key format.
2. Cloudflare Pages project > Settings > Variables and Secrets: add a Secret named GROQ_API_KEY and paste the key there.
3. Optionally add GROQ_MODEL with a model available to your Groq account; default is llama-3.3-70b-versatile.
4. Redeploy. Never paste the secret into index.html or public GitHub code.
5. Add rate limiting / quotas before public launch to prevent abuse and unexpected API bills.

BEFORE PUBLIC LAUNCH
- Test signup, email confirmation, login, creating/deleting projects, and data isolation using two different accounts.
- Configure custom domain, abuse/rate limiting, privacy policy and terms if collecting user data.
- Use strong email provider/security settings and review Supabase quotas/billing.
- AI requests are not authenticated or rate-limited in this starter. Do not enable public AI traffic until you add rate limiting and abuse protection to the function.
- The code editor is a text editor and downloads code; it does not run arbitrary projects on a secure sandbox.
- Three.js is loaded from jsDelivr, so the hologram requires internet access.
- No live domain can be published by this archive alone: you must create the Supabase/Cloudflare projects and configure the keys above.
