export async function onRequestPost({ request, env }) {
  const headers = { "Content-Type": "application/json", "Cache-Control": "no-store" };
  const json = (status, body) => new Response(JSON.stringify(body), { status, headers });
  if (!env.GROQ_API_KEY) return json(503, { error: "AI service is not configured. Add GROQ_API_KEY as a Cloudflare Pages secret." });
  let body;
  try { body = await request.json(); } catch { return json(400, { error: "Invalid JSON request." }); }
  const message = typeof body.message === "string" ? body.message.trim() : "";
  if (!message) return json(400, { error: "Message is required." });
  if (message.length > 6000) return json(413, { error: "Message is too long (maximum 6000 characters)." });
  try {
    const upstream = await fetch("https://api.groq.com/openai/v1/chat/completions", {
      method: "POST",
      headers: { "Authorization": `Bearer ${env.GROQ_API_KEY}`, "Content-Type": "application/json" },
      body: JSON.stringify({
        model: env.GROQ_MODEL || "llama-3.3-70b-versatile",
        messages: [
          { role: "system", content: "You are the VORTX HUB coding assistant. Be helpful, safe, concise, and explain code clearly. Reply in the language used by the user." },
          { role: "user", content: message }
        ],
        max_tokens: 1200
      })
    });
    const data = await upstream.json();
    if (!upstream.ok) return json(502, { error: data?.error?.message || "Groq API request failed." });
    return json(200, { reply: data?.choices?.[0]?.message?.content || "No response returned." });
  } catch {
    return json(502, { error: "Unable to reach Groq API." });
  }
}
